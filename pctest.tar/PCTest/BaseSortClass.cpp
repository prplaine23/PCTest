#include "BaseSortClass.h"
#include <assert.h>


void BaseSortClass::writeData( std::vector<int> theData, std::ostream outFile )
{
    std::vector<int>::iterator itr = theData.begin();

    while (itr != theData.end() ) {
        resultFile << *itr;
        ++itr;
    }
    resultFile << std::endl;
}

void BaseSortClass::writeData( int *theData, int count)
{
    for ( int i = 0; i <= count; i++) {
        resultFile << *(theData + i) ;
    }
    resultFile << std::endl;
}
