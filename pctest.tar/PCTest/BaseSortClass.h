#ifndef __BASECLASS_H_INCLUDED__
#define __BASECLASS_H_INCLUDED__

#include <fstream>
#include <iostream>
#include <vector>
#include <pthread.h>

class BaseSortClass {
public:
    BaseSortClass(){}
    virtual void sortData( const char* theItem ) = 0;
    virtual ~BaseSortClass() {}
    void writeResults();
    void writeData( std::vector<int> theData, std::ostream outFile );
    void writeData( int *theData, int count, std::ostream outFile );

//public:
//    std::filebuf *dataBuf;
public:
    // debugging
    int myThreadId;
    int lineNumber;
    // enddebugging
};
#endif // __BASECLASS_H_INCLUDED__
