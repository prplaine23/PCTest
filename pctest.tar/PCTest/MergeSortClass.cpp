#include "MergeSortClass.h"

//
//..startSort - make the initial sort function call. Mergesort will operate on
//             the data recursively.
//
void MergeSortClass::startSort()
{
    resultData = mergeSort(inputData);
}

//
//..mergeHalves - merge the two subarrays and return the result.
//
std::vector<int> MergeSortClass::mergeHalves( std::vector<int> leftV, std::vector<int> rightV)
{
    std::vector<int> mergeOut;
    std::vector<int>::iterator lItr = leftV.begin();
    std::vector<int>::iterator rItr = rightV.begin();

    for (int idx = 0; idx < (static_cast<int>(leftV.size()) + static_cast<int>(rightV.size()) ); idx++ ) {
        if ( lItr != leftV.end() && rItr != rightV.end() ) {
            if ( *lItr < *rItr ) {
                mergeOut.push_back( *lItr );
                ++lItr;
            } else {
                mergeOut.push_back( *rItr );
                ++rItr;
            }
        } else {
            if ( lItr == leftV.end() ) {
                mergeOut.push_back( *rItr );
                ++rItr;
                continue;
            }
            if ( rItr == rightV.end()) {
                mergeOut.push_back( *lItr );
                ++lItr;
                continue;
            }
        }
    }

    return mergeOut;
}
//
//..mergeSort - the recursive sorting call.
//
std::vector<int> MergeSortClass::mergeSort( std::vector<int> input )
{
    // if the input size is <= 1 we're finished. Just return
    if ( input.size() <= 1 ) return input;

    std::vector<int> sortedData;
    std::vector<int> leftV, rightV;
    std::vector<int> mLeft, mRight;

    // split the array
    for ( int i = 0; i < static_cast<int>(input.size()); i++ ) {
        if ( i < static_cast<int>(input.size())/2 ) leftV.push_back( input[i]);
        else rightV.push_back( input[i] );
    }

    // operate on the two halves.

    mLeft = mergeSort( leftV );
    mRight = mergeSort( rightV );

    return mergeHalves( mLeft, mRight);
}
