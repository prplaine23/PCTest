#include <iostream>
#include <vector>

#define MAX_ITEM_LENGTH 100

class MergeSortClass {
    
public:
    MergeSortClass() {}
    ~MergeSortClass() {}

    void startSort();
    std::vector<int> getSortResults() { return resultData; }

public:
    std::vector<int> inputData;

private:
    std::vector<int> resultData;
    std::vector<int> mergeHalves( std::vector<int> leftV, std::vector<int> rightV);
    std::vector<int> mergeSort( std::vector<int> input );
};
