#include "QuickSortClass.h"

//
//..startSort - make the initial sort function call. quickSort will operate on
//             the data recursively.
//
void QuickSortClass::startSort()
{
    quickSort( 0, inputCnt-1);
}
//
//..partition - working on a subarray, move the values that are less than
//              the pivot value (pivotVal) to the section of subArray
//              containing numbers smaller than the pivot value.
//
int QuickSortClass::partition( int start, int end)
{
    int i = start + 1;
    int pivotVal = *(inputData + start);

    for ( int j = start+1; j <= end; j++) {
        if ( *(inputData + j) < pivotVal ) {
            std::swap( *(inputData + i), *(inputData + j) );
            i++;
        }
    }
    
    std::swap(*(inputData + start), *(inputData + (i-1)));
    
    return (i - 1);
}
//
//..quickSort - the recursive sorting function
//
void QuickSortClass::quickSort( int start, int end )
{
    if ( start > end ) return;

    int pIdx = 0;
    // chose pivot index
    int randomIdx = start + (rand() % ((end - start) + 1));

    std::swap(inputData[randomIdx], inputData[start]);

    pIdx = partition( start, end );

    quickSort( start, pIdx-1 );
    quickSort( pIdx+1, end );

    return;
}
