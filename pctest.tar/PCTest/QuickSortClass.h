#include <iostream>
#include <vector>

#define MAX_ITEM_LENGTH 100

class QuickSortClass {
    
public:
    QuickSortClass() { inputCnt = 0;}
    ~QuickSortClass() {}

    void startSort();

public:
    int inputData[MAX_ITEM_LENGTH];
    int inputCnt;

private:
    int partition( int start, int end);
    void quickSort( int start, int end );
};
