
#include <iostream>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cstring>
#include <pthread.h>
#include <unistd.h>
#include "MergeSortClass.h"
#include "QuickSortClass.h"

using namespace std;

#define MAX_THREADS 4
#define MAX_ITEM_LENGTH 100
#define MAX_INPUT_BUFFER_SIZE 256
#define MAX_LINES_TO_PROCESS 10000

pthread_mutex_t writeMutex;
std::ofstream resultFile;


struct thread_data {
    int theThreadId;
    int estCharCnt;
    char anItem[MAX_INPUT_BUFFER_SIZE];
};

int convertChar( char inChar ) {
    int result = inChar - 48;
    if ( (result < 0) || (result > 48) ) {
        return -1;
    }
    return result;
}

void *mergeSortFunction(void *threadArgs)
{
    struct thread_data *myData;
    myData = static_cast<struct thread_data *>(threadArgs);

    pthread_mutex_lock(&writeMutex);

    MergeSortClass sortObj;
    //
    // convert the input data into an integer vector in sortObj.
    //
    for ( int c = 0; c < myData->estCharCnt; c++ ) {
        // make sure that we don't process past the '\0'.
        if ( myData->anItem[c] == 0x00 ) break;
        // if aChar is space then wait 1 second, reacquire the lock and continue.
        if ( myData->anItem[c] == 0x20 ) {
            pthread_mutex_unlock(&writeMutex);
            usleep(1000);
            pthread_mutex_lock(&writeMutex);
        } else {
            int convertedVal = convertChar( myData->anItem[c]);
            if ( convertedVal < 0 ) {
                std::cout << "ERROR:  Bad data. Skipping." << std::endl;
                continue;
            }
            sortObj.inputData.push_back(convertedVal);
        }
    }

    //
    // start the sort.
    //
    sortObj.startSort();

    std::vector<int> result = sortObj.getSortResults();
    std::vector<int>::iterator itr = result.begin();
    //
    // write the results to the output file
    //
    while (itr != result.end() ) {
        resultFile << *itr;
        ++itr;
        if ( itr != result.end() ) resultFile << ",";
    }
    resultFile << std::endl;
    pthread_mutex_unlock(&writeMutex);
    pthread_exit(nullptr);
}

void *quickSortFunction(void *threadArgs) {
    struct thread_data *myData;
    myData = static_cast<struct thread_data *>(threadArgs);

    pthread_mutex_lock(&writeMutex);

    QuickSortClass sortObj;
    //
    // convert the input data into an integer array in sortObj.
    //
    for ( int c = 0; c < myData->estCharCnt; c++ ) {
        // make sure that we don't process past the '\0'.
        if ( myData->anItem[c] == 0x00 ) break;
        // if aChar is space then wait 1 second then continue.
        if ( myData->anItem[c] == 0x20 ) {
            pthread_mutex_unlock(&writeMutex);
            usleep(1000);
            pthread_mutex_lock(&writeMutex);
        } else {
            int convertedVal = convertChar( myData->anItem[c]);
            if ( convertedVal < 0 ) {
                std::cout << "ERROR:  Bad data. Skipping." << std::endl;
                continue;
            }
            sortObj.inputData[sortObj.inputCnt] = convertedVal;
            sortObj.inputCnt++;
        }
    }
    //
    // run the sort operation
    //
    sortObj.startSort();
    //
    // write the results to the out put file
    //
    for ( int i = 0; i < sortObj.inputCnt; i++) {
        resultFile << sortObj.inputData[i];
        if ( i != sortObj.inputCnt-1 ) {
            resultFile << ",";
        }
    }
    resultFile << std::endl;

    pthread_mutex_unlock(&writeMutex);
    pthread_exit(nullptr);
}
//
//..printCommandLineError - report a help message if there are errors on the command line.
//
void printCommandLineError()
{
    std::cout << "PCTest" << std::endl;
    std::cout << "     ERROR: Invalid comman line arguments." << std::endl;
    std::cout << "            expect - inputFilepath outputFilepath sortAlgorithm" << std::endl;
    std::cout << "            where sortAlgorithm is \'merge\' or \'quick\' " << std::endl;
}
//
//..fexists - if the input file doesn't exist we don't want to waste our time.
//
bool fexists(const char *filename) {
  std::ifstream ifile(filename);
  return static_cast<bool>(ifile);
}

int main(int argc, char *argv[])
{
    if (argc < 4) {
        printCommandLineError();
        exit(EXIT_FAILURE);
    }

    if ( (strcmp( argv[3], "merge") != 0) && (strcmp( argv[3], "quick") != 0)) {
        printCommandLineError();
        exit(EXIT_FAILURE);
    }

    if (!fexists(argv[1])) {
        std::cout << "ERROR: input file [ "<< argv[1] << " ]" << " does not exist." << std::endl;
        exit(EXIT_FAILURE);
    }

    std::ifstream dataFile;
    std::string inputPath = argv[1];
    std::string outputPath = argv[2];
    string mergeType = argv[3];

    try {
        dataFile.open( inputPath );
    } catch (std::ios_base::failure& e) {
        std::cerr << e.what() << std::endl;
        exit(EXIT_FAILURE);
    }

    try {
        resultFile.open( outputPath, std::ios::out | std::ios::trunc);
    }  catch (std::ios_base::failure& e) {
        std::cerr << e.what() << std::endl;
        exit(EXIT_FAILURE);
    }

    pthread_t threads[MAX_THREADS];
    pthread_attr_t tdAttr;
    struct thread_data td[MAX_THREADS];
    int tdCreateSuccess;

    if ( pthread_mutex_init(&writeMutex, nullptr) != 0 ) {
        std::cout << "ERROR: Unable to initialize the mutex. Exiting" << std::endl;
        exit(EXIT_FAILURE);
    }
    pthread_attr_init( &tdAttr );
    pthread_attr_setdetachstate(&tdAttr, PTHREAD_CREATE_JOINABLE );

    char inStream[MAX_INPUT_BUFFER_SIZE];
    int lineCnt = 0;
    do {
        for ( int idx = 0; idx < MAX_THREADS; idx++ ) {
            dataFile.getline( inStream, MAX_INPUT_BUFFER_SIZE );
            td[idx].estCharCnt = (dataFile.gcount() <= MAX_ITEM_LENGTH) ? static_cast<int>(dataFile.gcount()) : MAX_ITEM_LENGTH;
            if ( inStream[0] == 0x00 ) break;
            td[idx].theThreadId = idx;
            strcpy(td[idx].anItem, inStream );
            if ( mergeType == "merge" ) {
                tdCreateSuccess = pthread_create( &threads[idx], &tdAttr, mergeSortFunction,
                                                  static_cast<void*>( &td[idx]));
                if ( tdCreateSuccess ) {
                    std::cout << "ERROR: unable to create thread" << tdCreateSuccess << std::endl;
                    exit(EXIT_FAILURE);
                }
            } else if ( mergeType == "quick" ) {
                tdCreateSuccess = pthread_create( &threads[idx], &tdAttr, quickSortFunction,
                                                  static_cast<void*>( &td[idx]));
                if ( tdCreateSuccess ) {
                    std::cout << "ERROR: unable to create thread" << tdCreateSuccess << std::endl;
                    exit(EXIT_FAILURE);
                }
            }
            ++lineCnt;
        }
        for ( int jdx = 0; jdx < MAX_THREADS; jdx++ ) {
            pthread_join(threads[jdx], nullptr);
        }
        if ( lineCnt >= MAX_LINES_TO_PROCESS ) break;
    } while (!dataFile.eof());

    if ( lineCnt == 0 ) {
        std::cout << "ERROR: input file [ "<< inputPath << " ]" << " appears to be empty." << std::endl;
        exit(EXIT_FAILURE);
    }
    // free attribute and wait for the other threads
    pthread_attr_destroy(&tdAttr);

    dataFile.close();
    resultFile.close();

    pthread_exit(nullptr);
}
